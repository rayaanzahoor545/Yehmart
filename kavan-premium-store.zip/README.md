# KAVAN — Premium Single-Vendor E-Commerce Platform

A production-grade, single-vendor modern Pakistani digital storefront inspired by the design philosophy, aesthetic restraint, and tactile commerce experience of top-tier brands like Zaryon (`zaryon.pk`).

---

## Key Features

- **Store Architecture**: Single-vendor, single-store model. No multi-vendor clutter, seller dashboards, or vendor commissions.
- **Pakistani E-Commerce Optimized**:
  - Currency: Native Pakistani Rupee (`PKR` / `Rs.`) with tabular formatting.
  - Cash on Delivery (COD) first-class workflow + Direct Bank Transfer (Raast / Meezan / HBL / Alfalah).
  - Pre-integrated Pakistani Courier Services: TCS Express, Leopards Courier, PostEx, Trax.
  - Automated Free Delivery threshold calculator (Free above Rs. 2,000).
- **Storefront & Catalog**:
  - 3-Zone Top Navigation following strict Frontend Design rules.
  - Optional, non-blocking 3D Spatial Canvas with 1-click **Skip Intro**.
  - Dynamic Flash Sale with live server-backed countdown timer (`HH:MM:SS`).
  - Asymmetric curated Category Showcase.
  - Product cards with secondary hover image reveal, discount badges, and stock level warnings.
  - Interactive Quick View modal with instant **Buy Now (COD)**.
  - Dynamic Price Collections ("Under Rs. 2,500", "Under Rs. 5,000", "Under Rs. 10,000").
- **Cart & Atomic Checkout**:
  - Slide-out Cart Drawer with visual free-shipping progress meter.
  - Dedicated full cart page with real-time promo code engine (`WELCOME10`, `KAVANVIP`, `FREESHIP`, `EID2026`).
  - Single-page checkout with Pakistani address inputs (Sector, City, Province, 03XX mobile phone).
  - Celebration confetti and printable receipt invoice.
- **Logistics & Order Tracking**:
  - `/track-order`: Multi-stage courier timeline (Placed → Confirmed → Inspected/Packed → Handed to Courier → Delivered & COD Settled).
  - Event history audit trail.
- **Store Admin Portal**:
  - Access via the **Store Admin ⚙** button in the top bar or `/admin`.
  - Executive KPI cards: Total PKR Revenue, Total Orders, Average Order Value (AOV), Pending Orders.
  - Catalog CRUD: Create products, adjust retail & compare-at prices, upload images, manage SKUs.
  - Order Fulfillment: Update consignment statuses, assign TCS/Leopards tracking numbers.
  - Low-stock inventory alert monitors.
  - Coupon code generator (Percentage or Fixed PKR discounts with minimum spend rules).

---

## Supabase PostgreSQL Database Setup

The complete production DDL, RLS policies, and stored procedures are in:
```
supabase/schema.sql
```

To deploy to your Supabase project:
1. Open your Supabase Dashboard → SQL Editor.
2. Paste the contents of `supabase/schema.sql` and run.
3. In your project settings, copy `URL` and `anon key` to your `.env` file:
   ```env
   VITE_SUPABASE_URL="https://your-project.supabase.co"
   VITE_SUPABASE_ANON_KEY="your-anon-key"
   ```

*Note: The platform features a built-in persistent storage engine that mirrors the schema in `localStorage`. All orders, inventory deductions, status changes, and reviews persist seamlessly even before linking external Supabase credentials.*

---

## Quick Demo References

- **Demo Admin Mode**: Click **"Mode: Customer 🛍"** in the top announcement bar to instantly toggle into **"Store Admin ⚙"**.
- **Active Promo Codes**:
  - `WELCOME10`: 10% discount on orders above Rs. 1,500.
  - `KAVANVIP`: 15% discount on orders above Rs. 3,000.
  - `FREESHIP`: Rs. 199 discount (covers standard delivery fee).
- **Demo Order Tracking**:
  - `KVN-2026-8812` (In-transit via TCS Express)
  - `KVN-2026-8815` (Delivered via Leopards Courier)
